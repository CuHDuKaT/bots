token='5922318223:AAHQo1HhFP6_W81Bh1hLE1UfGDVb4hx5-cU'
admin=5745512040
admin1=5508708893

minimalka = 400
maximalka = 20000
vxodadmin='УПРАВЛЕНИЕ УЕБАНАМИ' #Слово для входа в админ панель (Доступно только для админов)
vxodworker='ВЫЕБАТЬ МАМОНТА'#Слово для входа в воркер панель (Доступно только для всех)
zalety = -1001583180279
bot_username = "sweet_tyanki_bot"


poderjka = "@MACTEP_CHIEF" #аккаунт техподдержки

maxpromo = 5000 #максимальная сумма промокода которую могут создать воркеры


